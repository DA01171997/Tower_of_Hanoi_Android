package com.example.jason.towers;

import android.graphics.Canvas;

/**
 * Created by JASON on 10/25/2017.
 */

public interface GameObject {
    public void draw(Canvas canvas);
    public void update();
}
